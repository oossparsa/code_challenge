package com.example.parsaBadiei;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParsaApplicationTests {

	@Test
	void contextLoads() {
	}

}
